<?php
class M_siswa extends CI_Controller {
	function cetak_nama()
	{
		$nama = "ALFREDO AKBAR";
		return $nama;
	}
}