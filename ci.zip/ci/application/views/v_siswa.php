<html>
<head>
	<title></title>
</head>
<body>
	<h1>HELLO, <?=$data_nama?></h1>
	<p>
		Ini merupakan pelajaran
		pertama saya bersama Codeigniter
	</p>

</body>
</html>