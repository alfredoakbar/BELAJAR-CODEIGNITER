<html>
<head>
	<title></title>
</head>
<body>
	<marquee><font color="blue">BELAJAR CODEIGNITER</font></marquee>
	<p><font color="brown">SAYA INGIN BELAJAR CODEIGNITER DARI PEMULA</font></p><br>

</body>
</html>
<?php

class Home extends CI_Controller {

	public function index()
	{
		echo "Nama Saya adalah ALFREDO AKBAR";
	}
}
