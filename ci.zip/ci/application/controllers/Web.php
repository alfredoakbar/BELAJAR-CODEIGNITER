<html>
<head>
	<title></title>
</head>
<body>
	<font color="red">BELAJAR CODEIGNITER</font>
	<marquee>WELCOME TO MY WEBSITE</marquee>
</body>
</html>
<?php if (! defined('BASEPATH'))
		exit ('No direct script access allowed');

class Web extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		echo "Hallo.. Guys Welcome Back My Website";
	}
}
