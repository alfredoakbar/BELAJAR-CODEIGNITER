<?php

class Siswa extends CI_Controller {
	function index()
	{
		// memanggil model m_siswa
		$this->load->model('m_siswa');
		// memanggil fungsi cetak_nama
		$data['data_nama'] = $this->m_siswa->cetak_nama();
		// mengirim data ke file v_siswa.php
		$this->load->view('v_siswa.php', $data);
	}
}
